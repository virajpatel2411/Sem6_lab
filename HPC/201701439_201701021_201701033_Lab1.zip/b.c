#include<stdio.h>
#include<math.h>
#include<omp.h>

void dummy()
{
	return;
}

int main() {
    double minSize,maxSize,total,size,runs,*a,*b,*c,*d;
    long long int i,j;
    minSize = pow(2,8);
    maxSize = pow(2,27);
    total = maxSize;
    FILE *f;
    f = fopen("data_n.txt","w");
    for(size = minSize;size<maxSize;size*=2)
    {
        runs = total/size;
        a = (double *)calloc(size,sizeof(double));
        b = (double *)calloc(size,sizeof(double));
        c = (double *)calloc(size,sizeof(double));
        d = (double *)calloc(size,sizeof(double));
	for(i=0;i<size;i++)
	{
		b[i] = 2;
		c[i] = 3;
		d[i] = 6;
	}
        double start = omp_get_wtime();
        for(j=1;j<runs;j++)
        {
            for(i=1;i<size;i++)
            {
                a[i] = b[i] + c[i]*d[i];
		if(i==-1)
		{
			dummy();
		}
            }
        }
        double end = omp_get_wtime() - start;
        double throughput = (sizeof(double)*2*total)/end;
        printf("Size  :  %e------Throughput :  %e",size,throughput);
	fprintf(f,"%e,",throughput);
        printf("\n");
    }
    return 0;    
}
