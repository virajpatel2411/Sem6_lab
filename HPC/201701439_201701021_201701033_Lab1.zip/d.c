#include <stdio.h>
#include<math.h>
#include<omp.h>
#define n 10000
 
void dummy()
{
	return;
}

int main() {
    double **mat,**s,val;
    int i,j,*v,c=1;
    mat  = (double**)calloc(n,sizeof(double*));
    s  = (double**)calloc(n,sizeof(double*));
    v  = (int*)calloc(n,sizeof(int));
    for(i=0;i<n;i++)
    {
        v[i] = 6;
    	mat[i]  = (double*)calloc(n,sizeof(double));
    	s[i]  = (double*)calloc(n,sizeof(double));
        for(j=0;j<n;j++)
        {
            s[i][j] = 5;
        }
    }
    double start_time = omp_get_wtime();
    double d,temp;
    for(i=0;i<n;i++)
    {
	d = -cos(2*val);
	val = (double)(v[i]%256);
        for(j=0;j<n;j++)
        {
            mat[j][i] = s[j][i]*(d);
	    if(c==0)
		dummy();
        }
    }
    double end_time = omp_get_wtime() - start_time;
    //printf("Time: %e:%e\n",start_time,omp_get_wtime());
    double throughput = (sizeof(double)*5*n*n)/(end_time);
    printf("\n Outside loop cos2\n");
    printf("------Throughput : %e----------------\n\n\n",throughput);

    return 0;
}
