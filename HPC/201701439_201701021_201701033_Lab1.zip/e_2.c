#include<stdio.h>
#include<omp.h>
#include<math.h>
#include<stdlib.h>
#define LL long long

#define max(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _a : _b; })

#define min(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a < _b ? _a : _b; })

int main(void) {
	LL int min_size = pow(2,10);
	LL int max_size = pow(2,10);
	LL int total = max_size;
	LL int i,j,k,l,kk,jj,size,cache_size,runs;
	LL int RUNS = 1;
	double start_time_c, end_time_c, start_time, end_time, d;

	// Standard Algorithm
	for(size = min_size; size <= max_size; size *= 2) {

		printf("\n\n%lld\n",size);
		
		float** A = (float**) malloc(size * sizeof(float*));
		for(i = 0; i < size; i++) {
			A[i] = (float*)malloc(size * sizeof(float));	
			for(j = 0; j < size; j++) {
				A[i][j] = 2;
			}
		}	

		float** B = (float**) malloc(size * sizeof(float*));
		for(i = 0; i < size; i++) {
			B[i] = (float*)malloc(size * sizeof(float));	
			for(j = 0; j < size; j++) {
				B[i][j] = 3;
			}
		}

		float** C = (float**) malloc(size * sizeof(float*));
		for(i = 0; i < size; i++) {
			C[i] = (float*)malloc(size * sizeof(float));	
			for(j = 0; j < size; j++) {
				C[i][j] = 0;
			}
		}

		// Calculate Compute Time
		start_time_c = omp_get_wtime();
		for(i = 0; i < size; i++) {
			for(j = 0; j < size; j++) {
				for(k = 0; k < size; k++) {
					d = 1 + 2 * 3;
				}
			}
		}
		end_time_c = omp_get_wtime() - start_time_c;
		

		// i,j,k
		start_time = omp_get_wtime();
		for(runs = 0; runs < RUNS; runs++) {
			for(i = 0; i < size; i++) {
				for(j = 0; j < size; j++) {
					for(k = 0; k < size; k++) {
						C[i][j] = C[i][j] + A[i][k] * B[k][j];
					}
				}
			}
		}
		end_time = omp_get_wtime() - start_time;
		end_time /= RUNS;

		printf("\ni j k\n");
		printf("%lld\t%f\t%f\n", size, end_time, (end_time_c)/(end_time - end_time_c));


		// i,k,j
		start_time = omp_get_wtime();
		for(runs = 0; runs < RUNS; runs++) {
			for(i = 0; i < size; i++) {
				for(k = 0; k < size; k++) {
					for(j = 0; j < size; j++) {
						C[i][j] = C[i][j] + A[i][k] * B[k][j];
					}
				}
			}
		}
		end_time = omp_get_wtime() - start_time;
		end_time /= RUNS;

		printf("\ni k j\n");
		printf("%lld\t%f\t%f\n", size, end_time, (end_time_c)/(end_time - end_time_c));


		// j,i,k
		start_time = omp_get_wtime();
		for(runs = 0; runs < RUNS; runs++) {
			for(j = 0; j < size; j++) {
				for(i = 0; i < size; i++) {
					for(k = 0; k < size; k++) {
						C[i][j] = C[i][j] + A[i][k] * B[k][j];
					}
				}
			}
		}
		end_time = omp_get_wtime() - start_time;
		end_time /= RUNS;

		printf("\nj i k\n");
		printf("%lld\t%f\t%f\n", size, end_time, (end_time_c)/(end_time - end_time_c));


		// j,k,i
		start_time = omp_get_wtime();
		for(runs = 0; runs < RUNS; runs++) {
			for(j = 0; j < size; j++) {
				for(k = 0; k < size; k++) {
					for(i = 0; i < size; i++) {
						C[i][j] = C[i][j] + A[i][k] * B[k][j];
					}
				}
			}
		}
		end_time = omp_get_wtime() - start_time;
		end_time /= RUNS;

		printf("\nj k i\n");
		printf("%lld\t%f\t%f\n", size, end_time, (end_time_c)/(end_time - end_time_c));


		// k,i,j
		start_time = omp_get_wtime();
		for(runs = 0; runs < RUNS; runs++) {
			for(k = 0; k < size; k++) {
				for(i = 0; i < size; i++) {
					for(j = 0; j < size; j++) {
						C[i][j] = C[i][j] + A[i][k] * B[k][j];
					}
				}
			}
		}
		end_time = omp_get_wtime() - start_time;
		end_time /= RUNS;

		printf("\nk i j\n");
		printf("%lld\t%f\t%f\n", size, end_time, (end_time_c)/(end_time - end_time_c));


		// k,j,i
		start_time = omp_get_wtime();
		for(runs = 0; runs < RUNS; runs++) {
			for(k = 0; k < size; k++) {
				for(j = 0; j < size; j++) {
					for(i = 0; i < size; i++) {
						C[i][j] = C[i][j] + A[i][k] * B[k][j];
					}
				}
			}
		}
		end_time = omp_get_wtime() - start_time;
		end_time /= RUNS;

		printf("\nk j i\n");
		printf("%lld\t%f\t%f\n", size, end_time, (end_time_c)/(end_time - end_time_c));
	}

	
}
