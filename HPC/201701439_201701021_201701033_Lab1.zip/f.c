#include<stdio.h>
#include<omp.h>
#include<math.h>
#include<stdlib.h>
#define LL long long

#define max(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _a : _b; })

#define min(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a < _b ? _a : _b; })

int main(void) {
	LL int min_size = pow(2,11);
	LL int max_size = pow(2,11);
	LL int total = max_size;
	LL int i,j,k,l,kk,jj,size,cache_size,runs;
	LL int RUNS = 5;
	double start_time_c, end_time_c, start_time, end_time, d;

	printf("Problem Size\tCompute Time\tCMA\n");

	// 2D Blocled MM
	LL int min_cache_line = pow(2,1);
	LL int max_cache_line = pow(2,10);

	for(cache_size = min_cache_line; cache_size <= max_cache_line; cache_size *= 2) {
		printf("\n\n\nCache Size: %lld", cache_size);
		printf("\n\nProblem Size\tCompute Time\tCMA\n");

		for(size = min_size; size <= max_size; size *= 2) {
			double** A = (double**) malloc(size * sizeof(double*));
			for(i = 0; i < size; i++) {
				A[i] = (double*)malloc(size * sizeof(double));	
				for(j = 0; j < size; j++) {
					A[i][j] = 2.5;
				}
			}	

			double** B = (double**) malloc(size * sizeof(double*));
			for(i = 0; i < size; i++) {
				B[i] = (double*)malloc(size * sizeof(double));	
				for(j = 0; j < size; j++) {
					B[i][j] = 3.75;
				}
			}

			LL int MATRIX_SIZE = size;
			LL int block_size = cache_size;

			end_time_c = omp_get_wtime();
			for(runs = 0; runs < RUNS; runs++) {
				for (k = 0; k < MATRIX_SIZE; k += block_size)
					for (j = 0; j < MATRIX_SIZE; j += block_size)
						for(kk=k;kk<min(k+block_size,MATRIX_SIZE);kk++)
							for(jj=j;jj<min(j+block_size,MATRIX_SIZE);jj++)
								B[jj][kk] = A[kk][jj];
			}
			end_time = omp_get_wtime() - end_time_c;
			end_time /= RUNS;

			printf("%lld\t%f\t%f\n", size, end_time);
		}
	}

	
}
